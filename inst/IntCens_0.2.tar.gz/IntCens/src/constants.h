#include <Rcpp.h>
using namespace Rcpp;

// Date: Sep 2015
// Author: paulbunn@email.unc.edu (Paul Bunn)
//
// Description: Constants.

#ifndef CONSTANTS_H
#define CONSTANTS_H

extern const double Z_SCORE_FOR_TWO_TAILED_FIVE_PERCENT;
extern const double PHB_PI;
extern const double DELTA;
extern const double EPSILON;

extern const char PHB_NA_STRING[];
extern const char RHS_STRING[];

#endif
