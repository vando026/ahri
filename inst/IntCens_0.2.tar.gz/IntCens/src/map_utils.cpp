#include <Rcpp.h>
using namespace Rcpp;

// Date: May 2015
// Author: paulbunn@email.unc.edu (Paul Bunn)

#include "map_utils.h"

#include <map>
#include <set>

using namespace std;
