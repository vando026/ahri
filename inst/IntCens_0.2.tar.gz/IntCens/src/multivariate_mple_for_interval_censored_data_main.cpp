#include <Rcpp.h>
using namespace Rcpp;

// Date: Dec 2015
// Author: paulbunn@email.unc.edu (Paul Bunn)

// Usage:
//   Valid --model formats:
//     1) Time-Dependent:
//          (TIME, STATUS) = MODEL_RHS
//     2) Time-Independent:
//          ([STATUS_VAR_1 : ]LEFT-END_1, RIGHT-END_1;
//           [STATUS_VAR_2 : ]LEFT-END_2, RIGHT-END_2;
//           ...
//           [STATUS_VAR_K : ]LEFT-END_K, RIGHT-END_K) = MODEL_RHS
//   Where 'TIME' and 'STATUS' refer to the names of these columns (in the
//   time-dependent case), and 'LEFT-END' and 'RIGHT-END' refer to the names
//   of the interval endpoint columns (in the time-independent case); and
//   MODEL_RHS is a mathematical expression involving the covariates.
// Note that the id_col argument should be provided iff the data has the
// time-dependent format (and in particular, the --model argument has
// format (1) from above).
// See comments in command_line_utils.h for accepted formats of the args:
//   - extrapolation:   See ParseTimeDependentParams()
//   - standardization: See ParseVariableNormalizationParams()
//   - collapse:        See ParseCollapseParams()
#include "command_line_utils.h"
#include "read_input.h"
#include "read_time_dep_interval_censored_data.h"
#include "read_time_indep_interval_censored_data.h"
#include "mple_for_interval_censored_data.h"
#include "multivariate_mple_for_interval_censored_data.h"
#include "regression_utils.h"
#include "statistics_utils.h"

#include <cstdlib>
#include <Eigen/Dense>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

using Eigen::MatrixXd;
using Eigen::VectorXd;
using namespace std;

std::string PrintMultiUsage() {
  return "\nProper Usage:\n"
       "./multivariate_mple_for_interval_censored_data_main.exe "
       "--in /path/to/input.txt "
       "--out /path/to/output.txt "
       "--model \"(time, status)=X_1+X_2+...\" "
       "--r COMMA_SEP_LIST "
       "[--id_col ID_COLUMN_NAME] "
       "[--inf_char INFINITY_CHAR] "
       "[--sep INPUT_FILE_DELIMITER] "
       "[--comment_char COMMENT_CHAR] "
       "[--na_string \"{NA_1, NA_2, ...}\"] "
       "[--accuracy VALUE] [--spacing INT_VALUE] "
       "[--extrapolation TIME_PARAMS] "
       "[--standardization LIST_OF_VARS] "
       "[--collapse \"VAR_1 = {FROM_VAL_1, FROM_VAL_2, ...} -> TO_VAL; "
       "...; VAR_N = {FROM_VAL_1, FROM_VAL_2, ...} -> TO_VAL\"]\n\n";
}

bool ExtendLinearTermMeansAndStdDevToCovarianceMatrix(
    const std::vector<std::vector<std::tuple<bool, double, double>>>& linear_terms_means_and_std_dev,
    std::vector<std::tuple<bool, double, double>>* variance_matrix_means_and_std_dev) {
  const int K = linear_terms_means_and_std_dev.size();
  if (K == 0) {
    Rcout << "ERROR: no model." << endl;
    return false;
  }
  const int p = linear_terms_means_and_std_dev[0].size();
  if (K == 1 || linear_terms_means_and_std_dev[0].empty()) {
    *variance_matrix_means_and_std_dev = linear_terms_means_and_std_dev[0];
    return true;
  }

  variance_matrix_means_and_std_dev->clear();

  // Add the means and std deviation for each model.
  for (const std::vector<std::tuple<bool, double, double>>& linear_terms_means_and_std_dev_k :
       linear_terms_means_and_std_dev) {
    // Add the mean and standard deviation for each covariate of the k^th model.
    for (const std::tuple<bool, double, double>& linear_terms_means_and_std_dev_kp :
         linear_terms_means_and_std_dev_k) {
      variance_matrix_means_and_std_dev->push_back(linear_terms_means_and_std_dev_kp);
    }
  }
  // Finally, add the mean/std_dev for the "covariance" column/row.
  variance_matrix_means_and_std_dev->push_back(std::make_tuple(false, 0.0, 1.0));

  return true;
}

bool PrintOutput(
    const std::string& output_file,
    const int num_subjects,
    const std::vector<std::string>& status_var_names,
    const std::vector<std::vector<std::string>>& legend,
    const double& final_likelihood,
    const double& covariance,
    const std::vector<DependentCovariateInfo>& orig_input,
    const std::vector<DependentCovariateEstimates>& estimates,
    const MatrixXd* variance) {
  // Covariance Matrix will have Dim (1 + \sum p_k, 1 + \sum p_k): Each of the K
  // covariates \beta_k has size p_k, and an extra covariate for \sigma^2.
  int sum_p = 0;
  for (const std::vector<std::string>& legend_k : legend) {
    sum_p += legend_k.size();
  }

  const int K = estimates.size();
  const int cov_size = sum_p + (K == 1 ? 0 : 1);
  if (K == 0 || orig_input.size() != K ||
      (!status_var_names.empty() && status_var_names.size() != K) ||
      (variance != nullptr &&
      (variance->rows() != cov_size || variance->cols() != cov_size))) {
    Rcout << "ERROR in Printing Output: Bad input." << endl
         << "K: " << K << ", cov_size: " << cov_size
         << ", status_var_names.size(): " << status_var_names.size() << endl;
    if (variance != nullptr) {
      Rcout << ", variance->rows(): " << variance->rows()
           << ", variance->cols(): " << variance->cols() << endl;
    }
    return false;
  }

  ofstream outfile;
  outfile.open(output_file.c_str());

  // Print Metadata (command, num subjects, num distinct time points).
  outfile << "Num Subjects: " << num_subjects << endl
          << "Num dependent variables: " << K << endl
          << "Num distinct time points:\n";
  for (int k = 0; k < K; ++k) {
    const std::string dep_var_name = status_var_names.empty() ?
    "Dependent Variable " + Itoa(k + 1) : status_var_names[k];
    outfile << "\tFor " << dep_var_name << ": "
            << orig_input[k].distinct_times_.size() << endl;
  }
  outfile << "Log-Likelihood at the final estimates: " << final_likelihood;
  outfile << endl << endl;
  outfile << "###############################################################";
  outfile << endl;

  // Covariance (\sigma).
  if (K > 1) {
    if (covariance == 0.0) {
      outfile << "Covariance (sigma^2): 0.0" << endl;
    } else {
      outfile << "Covariance (sigma^2): " << setprecision(17) << covariance << endl;
    }
  }

  // Algorithm failed (or hasn't finished), but print out final beta, lambda, and
  // covariance (sigma) values.
  if (variance == nullptr) {
    Eigen::IOFormat format(Eigen::FullPrecision);
    for (int k = 0; k < estimates.size(); ++k) {
      outfile << "Beta_" << k + 1 << ":\n"
              << estimates[k].beta_.transpose().format(format) << endl
              << "Lambda_" << k + 1 << ":\n"
              << estimates[k].lambda_.transpose().format(format) << endl;
    }
    outfile << endl;
    outfile.close();
    return true;
  }

  // Variance.
  outfile << setprecision(17);
  if (sum_p > 1 || K > 1) {
    outfile << endl << "Covariance Matrix for the Estimates:" << endl << "\t";
    for (int k = 0; k < K; ++k) {
      for (int i = 0; i < legend[k].size(); ++i) {
        outfile << "\t" << legend[k][i] << "_" << k + 1;
      }
    }
    if (K != 1) {
      outfile << "\t" << "sigma^2";
    }
  } else {
    outfile << endl << "Variance:";
  }
  outfile << endl;
  int current_index = 0;
  for (int k = 0; k < K; ++k) {
    for (int i = 0; i < legend[k].size(); ++i) {
      outfile << legend[k][i] << "_" << k + 1 << ":";
      for (int j = 0; j < cov_size; ++j) {
        outfile << "\t" << (*variance)(current_index, j);
      }
      ++current_index;
      outfile << endl;
    }
  }
  if (K != 1) {
    outfile << "sigma^2:";
    for (int j = 0; j < cov_size; ++j) {
      outfile << "\t" << (*variance)(sum_p, j);
    }
    outfile << endl;
  }

  // Print out Beta for each (dependent) covariate.
  current_index = 0;
  for (int k = 0; k < K; ++k) {
    const std::string var_name =
      status_var_names.empty() ? "" : " (" + status_var_names[k] + ")";
    outfile << "###############################################################"
            << endl << "Estimates and Hazard Function for k = " << k + 1
            << var_name << endl;

    // Pick out the part of the Variance-Covariance matrix related to this k.
    VectorXd variance_k;
    variance_k.resize(legend[k].size());
    for (int i = 0; i < legend[k].size(); ++i) {
      variance_k(i) = (*variance)(current_index, current_index);
      ++current_index;
    }

    // Beta.
    const VectorXd& beta_k = estimates[k].beta_;
    if (beta_k.size() != legend[k].size()) {
      Rcout << "ERROR in Printing Output: Bad beta size: " << beta_k.size()
           << " does not match " << legend[k].size() << endl;
      outfile.close();
      return false;
    }

    // Get Summary Statistics.
    VectorXd z_stats, p_values;
    if (!GenerateSummaryStatistics(
        beta_k, variance_k, &z_stats, &p_values)) {
      Rcout << "ERROR: Failed to generate summary statistics for estimates:\n"
           << beta_k << "\nand Covariance Matrix:\n" << variance_k << endl
           << "ERROR: NEGATIVE VARIANCE DETECTED" << endl;
      outfile.close();
      return false;
    }

    outfile << setprecision(17);
    outfile << endl << "Covariate\tEstimate\tStd_Error\tZ-Stat\tP-value" << endl;
    for (int i = 0; i < legend[k].size(); ++i) {
      outfile << legend[k][i] << "\t" << beta_k(i) << "\t"
              << sqrt(variance_k(i)) << "\t" << z_stats(i) << "\t" << p_values(i)
              << endl;
    }

    // Print out Lambda for each (dependent) covariate.
    const VectorXd& lambda = estimates[k].lambda_;
    const std::set<double>& distinct_times_k = orig_input[k].distinct_times_;
    if (distinct_times_k.size() != lambda.size()) {
      Rcout << "ERROR: Mismatching number of distinct times for model " << k
           << "(" << distinct_times_k.size() << ") and size of lambda ("
           << lambda.size() << ")." << endl;
      outfile.close();
      return false;
    }
    outfile << endl << "Cummulative Hazard Function for " << k + 1
            << var_name << ":" << endl << "Time\tEstimate" << endl;
    int m = -1;
    double cumm_lambda = 0.0;
    for (const double& time : distinct_times_k) {
      ++m;
      cumm_lambda += lambda(m);
      outfile << setprecision(6) << time << "\t"
              << setprecision(10) << cumm_lambda << endl;
    }
  }
  outfile.close();

  return true;
}

bool ParseArgs(
    const std::vector<std::string>& argv, bool* standardize, bool* standardize_all,
    std::string* input_file, std::string* output_file, std::string* id_col_name,
    std::vector<std::string>* models, std::string* delimiter, std::string* comment_char,
    std::string* infinity_char, std::string* collapse, std::string* norm_params,
    std::string* time_params, std::string* na_strings,
    std::vector<double>* r, double* precision, int* spacing, int* max_itr,
    std::string* event_type, std::vector<std::string>* event_types) {
  // Start loop at '1' (argument 0 is the executable itself).
  // Start loop at '1' (argument 0 is the executable itself).
  const unsigned int argc = argv.size();
  if (argc != 15) {
    Rcout << "\nERROR: multireg expects 15 arguments, found "
          << argc << endl;
    return false;
  }
  for (unsigned int i = 0; i < argc; ++i) {
    const string& arg = StripAllEnclosingPunctuationAndWhitespace(argv[i]);
    if (i == 0) {
      *input_file = arg;
    } else if (i == 1) {
      *output_file = arg;
    } else if (i == 2) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse r parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
      std::vector<std::string> parts;
      Split(argv[i], ",", &parts);
      for (const std::string& part : parts) {
        double r_value;
        if (!Stod(part, &r_value)) {
          Rcout << "\nERROR: Unable to parse r parameter '"
                << part << "' as a numeric value.\nAborting.\n";
          return false;
        }
        r->push_back(r_value);
      }
    } else if (i == 3) {
      Split(arg, ";", models);
    } else if (i == 4) {
      *id_col_name = arg;
    } else if (i == 5) {
      *event_type = arg;
    } else if (i == 6) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse max_itr parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
      if (!Stoi(argv[i], max_itr)) {
        cout << "ERROR Reading Command: Unable to parse max_itr parameter '"


        << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (i == 7) {
      *delimiter = StripQuotes(argv[i]);
    } else if (i == 8) {
      *comment_char = arg;
    } else if (i == 9) {
      *infinity_char = arg;
    } else if (i == 10) {
      *na_strings = arg;
    } else if (i == 11) {
      *time_params = argv[i];
    } else if (i == 12) {
      *collapse = argv[i];
    } else if (i == 13) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse max_itr parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
      if (!Stod(argv[i], precision)) {
        cout << "ERROR Reading Command: Unable to parse "
             << "convergence_threshold parameter '"
             << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (i == 14) {
      Split(arg, ",", event_types);
    } else {
      Rcout << "\nERROR: Unexpected argument: " << argv[i] << endl;
      return false;
    }
  }

  return true;
}

bool SanityCheckArgs(
    const std::vector<std::string>& models,
    const std::string& input_file, const std::string& output_file,
    const std::string& id_col, const string& event_col,
    const std::vector<std::string>& event_types,
    const std::vector<double>& r_values) {
  for (const double& r : r_values) {
    if (r < 0.0) {
      Rcout << "ERROR: r values must be non-negative (found value "
            << r << ")." << endl;
      return false;
    }
  }

  if (models.empty()) {
    Rcout << "ERROR: You must specify at least one model (via model_k= "
          << "argument)." << endl;
    PrintMultiUsage();
    return false;
  }

  if (input_file.empty()) {
    Rcout << "ERROR: You must specify an input data file (via in= "
          << "argument)." << endl;
    PrintMultiUsage();
    return false;
  }

  if (output_file.empty()) {
    Rcout << "ERROR: You must specify an output data file (via out= "
          << "argument)." << endl;
    PrintMultiUsage();
    return false;
  }

  if (event_col.empty()) {
    return false;
  }

  if (event_types.empty() || r_values.size() != event_types.size() ||
      (models.size() != 1 && models.size() != r_values.size())) {
    Rcout << "ERROR: You must specify the same number of models ("
          << models.size() << "found), r-values ("
          << r_values.size() << "), and event types ("
          << event_types.size() << ")" << endl;
    return false;
  }
  return true;
}

//[[Rcpp::export]]
std::string MultivariateNPMLE(const std::vector<std::string>& multi_input) {
  std::string input_file = "";
  std::string output_file = "";
  std::string id_col_name = "";
  std::vector<std::string> models;
  std::string collapse = "";
  std::string norm_params = "";
  std::string time_params = "";
  std::string delimiter = " ";
  std::string comment_char = "";
  std::string infinity_char = "inf";
  std::string na_strings = "NA";

  // Parse Interval/Right-Censored program-specific command-line arguments.
  std::string event_type = "";
  std::vector<std::string> event_types;

  std::vector<double> r;
  double convergence_threshold = 0.005;
  int h_n_constant = 1;
  int max_itr = 5000;
  bool standardize = true;
  bool standardize_all = false;
  bool no_use_pos_def_variance = false;
  bool force_one_right_censored = true;
  if (!ParseArgs(multi_input, &standardize, &standardize_all,
                 &input_file, &output_file, &id_col_name, &models, &delimiter,
                 &comment_char, &infinity_char, &collapse,
                 &norm_params, &time_params, &na_strings, &r,
                 &convergence_threshold, &h_n_constant, &max_itr,
                 &event_type, &event_types)) {
                 PrintMultiUsage();
    return "ERROR: Unable to run multireg on parameters provided.\n" + PrintMultiUsage() + "\n";
  }

  // Sanity-Check provided command-line args are valid.
  if (!SanityCheckArgs(models, input_file, output_file,
                       id_col_name, event_type, event_types, r)) {
    return "\n" + PrintMultiUsage();
  }

  // Initialize data structure. First, fill all fields only
  // for the first model/event type.
  std::vector<ModelAndDataParams> all_models;
  all_models.push_back(ModelAndDataParams());
  ModelAndDataParams& params = all_models[0];
  params.model_type_ = ModelType::MODEL_TYPE_INTERVAL_CENSORED;
  params.id_str_ = id_col_name;
  params.collapse_params_str_ = collapse;
  params.time_params_str_ = time_params;
  params.var_norm_params_str_ = norm_params;
  params.standardize_vars_ =
    standardize_all ? VariableNormalization::VAR_NORM_STD_W_N_MINUS_ONE :
    standardize ? VariableNormalization::VAR_NORM_STD_W_N_MINUS_ONE_NON_BINARY :
    VariableNormalization::VAR_NORM_NONE;
  params.max_itr_ = max_itr;
  params.file_.name_ = input_file;
  params.outfile_.name_ = output_file;
  if (!comment_char.empty()) {
    params.file_.comment_char_ = comment_char;
    params.outfile_.comment_char_ = comment_char;
  }
  if (!infinity_char.empty()) {
    params.file_.infinity_char_ = infinity_char;
    params.outfile_.infinity_char_ = infinity_char;
  }
  if (!delimiter.empty()) {
    params.file_.delimiter_ = delimiter;
    params.outfile_.delimiter_ = delimiter;
  }
  if (!na_strings.empty()) {
    std::vector<string> na_strs;
    Split(StripQuotes(na_strings), ",", &na_strs);
    for (const string& na_str : na_strs) {
      params.file_.na_strings_.insert(na_str);
      params.outfile_.na_strings_.insert(na_str);
    }
  }

  // If only a single model was entered, copy it to all
  // event types.
  if (models.size() != r.size()) {
    const std::string& common_model = models[0];
    for (int i = 1; i < r.size(); ++i) {
      models.push_back(common_model);
    }
  }

  // Now copy parameters to all models.
  for (int i = 0; i < models.size(); ++i) {
    if (i != 0) {
      all_models.push_back(ModelAndDataParams());
    }
    ModelAndDataParams& params_k = all_models.back();
    params_k.model_str_ = models[i];
    CopyModelAndDataParams(all_models[0], &params_k);
    // Translate string versions of model parameters (i.e. Category 1 fields of
    // ModelAndDataParams) to the corresponding structures (Category 2 fields).
    if (!ParseModelAndDataParams(&params_k)) {
      return "ERROR in Parsing Model:\n" + params_k.error_msg_ + "\n";
    }
  }

  // Convert data into format accepted by underlying algorithm.
  TimeDepIntervalCensoredData data;
  if (!id_col_name.empty() &&
      !ReadTimeDepIntervalCensoredData::ReadFile(
          true, std::set<std::string>(), event_type, "",
          event_types, std::vector<std::string>(), all_models, &data)) {
    return "ERROR: Unable to parse data.\n\t" + data.error_msg_ + "\n";
  } else if (id_col_name.empty() &&
    !ReadTimeIndepIntervalCensoredData::ReadFile(
        std::set<std::string>(), event_type, "",
        event_types, std::vector<std::string>(), all_models, &data)) {
    return "ERROR: Unable to parse data.\n\t" + data.error_msg_ + "\n";
  }

  // Get a list of all the dependent variable names.
  std::vector<std::string> dep_vars_names;
  if (data.event_type_index_to_name_.empty()) {
    // If there is more than one event type, the should be names for each. Abort.
    if (all_models.size() != 1) {
      return "ERROR: Found " + Itoa(static_cast<int>(all_models.size())) +
             " dependent variables, " +
             "but no mapping between event-type and model index.\n";
    }
    // If the event_type_index_to_name_ field is empty, pull the names from the model
    // itself (assume all models have the same dep var names).
    dep_vars_names = all_models[0].model_lhs_.dep_vars_names_;
  } else {
    for (const auto& event_type_index_and_name : data.event_type_index_to_name_) {
      dep_vars_names.push_back(event_type_index_and_name.second);
    }
  }

  // Initialize global parameters for underlying algorithm.
  std::vector<DependentCovariateInfo> input;
  MultivariateMpleForIntervalCensoredData::SetLoggingOn(false);
  MultivariateMpleForIntervalCensoredData::SetForceOneRightCensored(force_one_right_censored);
  MultivariateMpleForIntervalCensoredData::SetNoUsePositiveDefiniteVariance(
    no_use_pos_def_variance);
  MultivariateMpleForIntervalCensoredData::SetNoComputeVariance(false);
  if (!MultivariateMpleForIntervalCensoredData::InitializeInput(
      r, data, &input)) {
    return "ERROR: Unable to parse input data.\n";
  }

  // Get number of each linear terms for each event type from the legend.
  std::vector<int> p;
  for (int k = 0; k < data.legend_.size(); ++k) {
    p.push_back(data.legend_[k].size());
  }

  // =============================== MPLE Start ================================
  const int max_times_em = 2;
  const int kAllowSecondPassTimeThreshold = 60 * 60 * 6;  // 6 hours.
  double final_likelihood = 0.0;
  std::vector<DependentCovariateEstimates> estimates;
  MatrixXd variance;
  double covariance;
  MpleReturnValue ret_value;
  const int orig_h_n_constant = h_n_constant;
  for (int num_times_em = 0; num_times_em < max_times_em; ++num_times_em) {
    time_t mple_start_time = time(nullptr);
    localtime(&mple_start_time);

    estimates.clear();
    std::vector<DependentCovariateEstimates> standardized_estimates;
    h_n_constant = orig_h_n_constant;
    int num_iterations = 0;
    ret_value =
      MultivariateMpleForIntervalCensoredData::PerformEmAlgorithmForParameterEstimation(
        convergence_threshold, h_n_constant, max_itr, input,
        &num_iterations, &final_likelihood, &covariance,
        &standardized_estimates, nullptr);
        if (ret_value != MpleReturnValue::SUCCESS &&
        ret_value != MpleReturnValue::FAILED_MAX_ITR) {
          return "ERROR in Performing E-M Algorithm for Parameter Estimation.\n";
        }

        // Unstandardize beta and variance values.
        std::string error_msg = "";
        if (!ReadTimeDepIntervalCensoredData::UnstandardizeBetaAndLambda(
            all_models[0].standardize_vars_, standardized_estimates,
            data.linear_terms_mean_and_std_dev_,
            &estimates, &error_msg)) {
          return error_msg + "\n";
        }

        // Print beta, lambda estimates to file (in case Variance computation fails).
        const std::string description = ret_value == MpleReturnValue::FAILED_MAX_ITR ?
        "As of the last iteration, " :
          "Even though Variance computation failed, estimates for "
          "beta and lambda are valid. ";
        const std::string output_message = description;
        if (!PrintOutput(
            output_file, data.subject_info_.size(),
            dep_vars_names,
            data.legend_, final_likelihood, covariance,
            input, estimates, nullptr)) {
          return "ERROR: Unable to print output.\n";
        }

        // Handle unsucessful run.
        if (ret_value != MpleReturnValue::SUCCESS) {
          return "ERROR in Performing E-M Algorithm for Parameter Estimation.\n";
        }

        // Now Compute Variance.
        const int max_times_neg_var = 3;
        for (int num_times_neg_var = 0; num_times_neg_var < max_times_neg_var;
        ++num_times_neg_var) {
          MatrixXd standardized_variance;
          if (estimates.size() == 1) {
            double integral_constant_factor;
            Expression transformation_G, transformation_G_prime;
            if (!MpleForIntervalCensoredData::InitializeInput(
                input[0].r_, &integral_constant_factor,
                &transformation_G, &transformation_G_prime)) {
              return "ERROR: Failed to compute variance.\n";
            }
            ret_value = MpleForIntervalCensoredData::ComputeVariance(
              transformation_G, transformation_G_prime,
              input[0].r_, integral_constant_factor, convergence_threshold,
              h_n_constant, max_itr, input[0].points_and_weights_,
              input[0].distinct_times_, input[0].lower_time_bounds_,
              input[0].upper_time_bounds_, input[0].time_indep_vars_,
              input[0].x_, input[0].r_star_,
              standardized_estimates[0].beta_, standardized_estimates[0].lambda_,
              &standardized_variance);
          } else {
            ret_value =
              MultivariateMpleForIntervalCensoredData::ComputeVariance(
                input[0].x_.size(), p, h_n_constant,
                max_itr, convergence_threshold, sqrt(covariance),
                input, standardized_estimates, &standardized_variance);
          }

          if (ret_value == MpleReturnValue::SUCCESS) {
            // Note that Covariance matrix is not (p, p), so we need to generate
            // the row/column statistics (mean, std dev) in order to unstandardize it:
            // In Particular, it is (p * K + 1, p * K + 1)(p * K + 1, p * K + 1), so
            // the p linear terms should have their means/std_deviations repeated K times,
            // and the 1 coordinate for "covariance" should get mean 0 and std_dev 1.
            std::vector<std::tuple<bool, double, double>> variance_matrix_means_and_std_dev;
            if (!ExtendLinearTermMeansAndStdDevToCovarianceMatrix(
                data.linear_terms_mean_and_std_dev_,
                &variance_matrix_means_and_std_dev)) {
              return "ERROR: Unable to compute variance.\n";
            }

            // Unstandardize Covariance Matrix.
            std::string error_msg = "";
            if (!UnstandardizeMatrix(
                all_models[0].standardize_vars_, standardized_variance,
                variance_matrix_means_and_std_dev,
                &variance, &error_msg)) {
              return error_msg + "\n";
            }
            break;
          }

          if (ret_value != MpleReturnValue::FAILED_NEGATIVE_VARIANCE) break;

          // Negative variance. Try to correct by increasing h_n constant.
          if (h_n_constant < 10) h_n_constant = 10;
          else break;
        }

        if (ret_value == MpleReturnValue::SUCCESS) break;

        // To reach here, only possibilities are ret_value equals
        // FAILED_VARIANCE or FAILED_NEG_VARIANCE. Abort in the former case,
        // while attempt to re-run to fix the problem in the latter case.
        if (ret_value == MpleReturnValue::FAILED_VARIANCE) {
          return "ERROR in Computing Variance. "
                 "Even though Variance computation failed, estimates for beta "
                 "and lambda in '" + output_file + "' are valid.\n";
        }

        // To reach here, Negative Covariance was encounterd (max_times_neg_var
        // times, or with all spacing (h_n) options exhausted). If time permits,
        // rerun E-M algorithm (with stricter convergence threshold) to get new
        // beta, lambda estimates, and try again to compute Covariance Matrix
        // using those.
        time_t mple_end_time = time(nullptr);
        localtime(&mple_end_time);
        time_t mple_elapsed_time = mple_end_time - mple_start_time;  // In seconds.
        if (mple_elapsed_time > kAllowSecondPassTimeThreshold) break;
        convergence_threshold /= 10.0;
        max_itr *= 2;
  }
  // ================================ MPLE END =================================

  if (ret_value == MpleReturnValue::FAILED_NEGATIVE_VARIANCE) {
    return "\nERROR: Information Matrix is not positive definite. "
           "Try rerunning multireg with decreased convergence_threshold "
           "and increased max_itr.\n";
  } else if (ret_value != MpleReturnValue::SUCCESS) {
    // The only non-success MpleReturnValue that can reach here is FAILED_VAR or
    // FAILED_NEG_VARIANCE (all the others have already done a "return -1" call).
    return "\nERROR in Computing Variance. "
         "Even though Variance computation failed, estimates for beta "
         "and lambda in '" + output_file + "' are valid.\n";
  }

  // (Re)Print results to file, now that we have covariance.
  if (!PrintOutput(
      output_file, data.subject_info_.size(),
      dep_vars_names, data.legend_, final_likelihood,
      covariance, input, estimates, &variance)) {
    return "ERROR printing output.\n";
  }

  time_t current_time = time(nullptr);
  return "\n" + string(asctime(localtime(&current_time))) +
    "Done running multireg.\nTotal Elapsed Time: ";
}
