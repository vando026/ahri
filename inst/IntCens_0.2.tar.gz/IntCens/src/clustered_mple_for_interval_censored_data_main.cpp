#include <Rcpp.h>
using namespace Rcpp;

// Date: Dec 2015
// Author: paulbunn@email.unc.edu (Paul Bunn)

// Usage:
//   Valid --model formats:
//     1) Time-Dependent:
//          (TIME, STATUS) = MODEL_RHS
//     2) Time-Independent:
//          ([STATUS_VAR_1 : ]LEFT-END_1, RIGHT-END_1;
//           [STATUS_VAR_2 : ]LEFT-END_2, RIGHT-END_2;
//           ...
//           [STATUS_VAR_K : ]LEFT-END_K, RIGHT-END_K) = MODEL_RHS
//   Where 'TIME' and 'STATUS' refer to the names of these columns (in the
//   time-dependent case), and 'LEFT-END' and 'RIGHT-END' refer to the names
//   of the interval endpoint columns (in the time-independent case); and
//   MODEL_RHS is a mathematical expression involving the covariates.
// Note that the id_col argument should be provided iff the data has the
// time-dependent format (and in particular, the --model argument has
// format (1) from above).
// See comments in command_line_utils.h for accepted formats of the args:
//   - extrapolation:   See ParseTimeDependentParams()
//   - standardization: See ParseVariableNormalizationParams()
//   - collapse:        See ParseCollapseParams()
#include "command_line_utils.h"
#include "read_input.h"
#include "read_time_dep_interval_censored_data.h"
#include "read_time_indep_interval_censored_data.h"
#include "mple_for_interval_censored_data.h"
#include "clustered_mple_for_interval_censored_data.h"
#include "regression_utils.h"
#include "statistics_utils.h"

#include <cstdlib>
#include <Eigen/Dense>
#include <fstream>
#include <iomanip>      // std::setprecision
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

using Eigen::MatrixXd;
using Eigen::VectorXd;
using namespace std;

std::string PrintClusteredUsage() {
  return "\nProper Usage:\n"
         "./clustered_mple_for_interval_censored_data_main.exe "
         "--in /path/to/input.txt "
         "--out /path/to/output.txt "
         "--model \"(time, status)=X_1+X_2+...\" "
         "--r COMMA_SEP_LIST "
         "[--id_col ID_COLUMN_NAME] "
         "[--inf_char INFINITY_CHAR] "
         "[--sep INPUT_FILE_DELIMITER] "
         "[--comment_char COMMENT_CHAR] "
         "[--na_string \"{NA_1, NA_2, ...}\"] "
         "[--accuracy VALUE] [--spacing INT_VALUE] "
         "[--extrapolation TIME_PARAMS] "
         "[--standardization LIST_OF_VARS] "
         "[--collapse \"VAR_1 = {FROM_VAL_1, FROM_VAL_2, ...} -> TO_VAL; "
         "...; VAR_N = {FROM_VAL_1, FROM_VAL_2, ...} -> TO_VAL\"]\n\n";
}

bool ExtendLinearTermMeansAndStdDevToCovarianceMatrix(
    const int K,
    const std::vector<tuple<bool, double, double>>& linear_terms_means_and_std_dev,
    std::vector<tuple<bool, double, double>>* variance_matrix_means_and_std_dev) {
  const int p = linear_terms_means_and_std_dev.size();
  if (p == 0 || K == 1) {
    *variance_matrix_means_and_std_dev = linear_terms_means_and_std_dev;
    return true;
  }

  variance_matrix_means_and_std_dev->clear();
  variance_matrix_means_and_std_dev->resize(p + 1);

  for (int i = 0; i < p; ++i) {
    (*variance_matrix_means_and_std_dev)[i] =
      linear_terms_means_and_std_dev[i];
  }

  // Finally, add the mean/std_dev for the "covariance" column/row.
  (*variance_matrix_means_and_std_dev)[p] = make_tuple(false, 0.0, 1.0);

  return true;
}

bool PrintOutput(
    const int n,
    const int K,
    const std::string& output_file,
    const std::vector<std::string>& status_cols,
    const std::vector<std::string>& legend,
    const double& final_likelihood,
    const double& covariance,
    const std::set<double>& distinct_times,
    const DependentCovariateEstimates& estimates,
    const MatrixXd* variance) {
  const int p = legend.size();
  const int cov_size = p + (K == 1 ? 0 : 1);
  if (p == 0 || K == 0 ||
      (!status_cols.empty() && status_cols.size() != 1) ||
      (variance != nullptr &&
      (variance->rows() != cov_size || variance->cols() != cov_size))) {
    Rcout << "ERROR in Printing Output: Bad input." << endl
         << "p: " << p << ", K: " << K << ", cov_size: " << cov_size
         << ", status_cols.size(): " << status_cols.size() << endl;
    if (variance != nullptr) {
      Rcout << ", variance->rows(): " << variance->rows()
           << ", variance->cols(): " << variance->cols() << endl;
    }
    return false;
  }

  ofstream outfile;
  outfile.open(output_file.c_str());

  // Print Metadata (command, num subjects, num distinct time points).
  outfile << "Num Subjects: " << n << endl
          << "Num Families: " << K << endl
          << "Num distinct time points: " << distinct_times.size() << endl
          << "Log-Likelihood at the final estimates: " << final_likelihood
          << endl << endl
          << "###############################################################"
          << endl;

  // Covariance (\sigma).
  if (K > 1) {
    if (covariance == 0.0) {
      outfile << "Covariance (sigma^2): 0.0" << endl;
    } else {
      outfile << "Covariance (sigma^2): " << setprecision(17) << covariance << endl;
    }
  }

  // Algorithm failed, but print out final beta, lambda, and covariance (sigma) values.
  if (variance == nullptr) {
    Eigen::IOFormat format(Eigen::FullPrecision);
    outfile << "Beta:\n"
            << estimates.beta_.transpose().format(format) << endl
            << "Lambda:\n"
            << estimates.lambda_.transpose().format(format) << endl;
    outfile << endl;
    outfile.close();
    return true;
  }

  // Variance.
  outfile << setprecision(17);
  if (p > 1 || K > 1) {
    outfile << endl << "Covariance Matrix for the Estimates:" << endl << "\t";
    for (int i = 0; i < p; ++i) {
      outfile << "\t" << legend[i];
    }
    if (K != 1) {
      outfile << "\t" << "sigma^2";
    }
  } else {
    outfile << endl << "Variance:";
  }
  outfile << endl;
  for (int i = 0; i < p; ++i) {
    outfile << legend[i] << ":";
    for (int j = 0; j < cov_size; ++j) {
      outfile << "\t" << (*variance)(i, j);
    }
    outfile << endl;
  }
  if (K != 1) {
    outfile << "sigma^2:";
    for (int j = 0; j < cov_size; ++j) {
      outfile << "\t" << (*variance)(p, j);
    }
    outfile << endl;
  }

  // Print out Beta.
  const std::string var_name = status_cols.empty() ? "" : " for " + status_cols[0];
  outfile << "###############################################################"
          << endl << "Estimates and Hazard Function"
          << var_name << endl;

  // Pick out the part of the Variance-Covariance matrix related to this beta.
  VectorXd beta_variance;
  beta_variance.resize(p);
  for (int i = 0; i < p; ++i) {
    beta_variance(i) = (*variance)(i, i);
  }

  // Beta.
  const VectorXd& beta = estimates.beta_;
  if (beta.size() != p) {
    Rcout << "ERROR in Printing Output: Bad beta size: " << beta.size()
         << " does not match " << p << endl;
    return false;
  }

  // Get Summary Statistics.
  VectorXd z_stats, p_values;
  if (!GenerateSummaryStatistics(
      beta, beta_variance, &z_stats, &p_values)) {
    Rcout << "ERROR: Failed to generate summary statistics for estimates:\n"
         << beta << "\nand Covariance Matrix:\n" << beta_variance << endl
         << "ERROR: NEGATIVE VARIANCE DETECTED" << endl;
    return false;
  }

  outfile << setprecision(17);
  outfile << endl << "Covariate\tEstimate\tStd_Error\tZ-Stat\tP-value" << endl;
  for (int i = 0; i < p; ++i) {
    outfile << legend[i] << "\t" << beta(i) << "\t"
            << sqrt(beta_variance(i)) << "\t" << z_stats(i) << "\t" << p_values(i)
            << endl;
  }

  // Print out Lambda.
  const VectorXd& lambda = estimates.lambda_;
  if (distinct_times.size() != lambda.size()) {
    Rcout << "ERROR: Mismatching number of distinct times ("
         << distinct_times.size() << ") and size of lambda ("
         << lambda.size() << ")." << endl;
    return false;
  }
  outfile << endl << "Cummulative Hazard Function:" << endl
          << "Time\tEstimate" << endl;
  int m = -1;
  double cumm_lambda = 0.0;
  for (const double& time : distinct_times) {
    ++m;
    cumm_lambda += lambda(m);
    outfile << setprecision(6) << time << "\t"
            << setprecision(10) << cumm_lambda << endl;
  }

  outfile.close();

  return true;
}

bool ParseClusteredNpmleArgs(
    int argc, char* argv[],
                        double* r, double* convergence_threshold, int* h_n_constant,
                        bool* no_pos_def_var, bool* force_one_right_censored) {
  // Start loop at '1' (argument 0 is the executable itself).
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg == "--pos_def_var") {
      *no_pos_def_var = false;
    } else if (arg == "--nopos_def_var") {
      *no_pos_def_var = true;
    } else if (arg == "--noforce_right_censored") {
      *force_one_right_censored = false;
    } else if (arg == "--r") {
      if (i == argc - 1) {
        Rcout << "ERROR Reading Command: Expected argument after '--r'.\n"
             << "Aborting.\n";
        return false;
      }
      ++i;
      const std::string r_str = StripAllEnclosingPunctuationAndWhitespace(argv[i]);
      if (!Stod(r_str, r)) {
        Rcout << "ERROR Reading Command: Unable to parse r value '"
             << r_str << "' (from --r parameter '"
             << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (arg == "--accuracy" || arg == "--precision" ||
      arg == "--convergence_threshold") {
      if (i == argc - 1) {
        Rcout << "ERROR Reading Command: Expected argument after '"
             << arg << "'.\nAborting.\n";
        return false;
      }
      ++i;
      if (!Stod(argv[i], convergence_threshold)) {
        Rcout << "ERROR Reading Command: Unable to parse "
             << "convergence_threshold parameter '"
             << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (arg == "--spacing") {
      if (i == argc - 1) {
        Rcout << "ERROR Reading Command: Expected argument after '--spacing'.\n"
             << "Aborting.\n";
        return false;
      }
      ++i;
      if (!Stoi(argv[i], h_n_constant)) {
        Rcout << "ERROR Reading Command: Unable to parse h_n parameter '"
             << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    }
  }

  return true;
}

bool ParseArgs(
    const std::vector<std::string>& argv, bool* standardize, bool* standardize_all,
    std::string* input_file, std::string* output_file,
    std::string* id_col_name, std::string* family_col_name,
    std::string* model, std::string* delimiter, std::string* comment_char,
    std::string* infinity_char, std::string* collapse, std::string* norm_params,
    std::string* time_params, std::string* na_strings,
    double* r, double* precision, int* spacing, int* max_itr) {
  // Start loop at '1' (argument 0 is the executable itself).
  // Start loop at '1' (argument 0 is the executable itself).
  const unsigned int argc = argv.size();
  if (argc != 14) {
    Rcout << "\nERROR: clustreg expects 14 arguments, found "
          << argc << endl;
    return false;
  }
  for (unsigned int i = 0; i < argc; ++i) {
    const string& arg = StripAllEnclosingPunctuationAndWhitespace(argv[i]);
    if (i == 0) {
      *input_file = arg;
    } else if (i == 1) {
      *output_file = arg;
    } else if (i == 2) {
      *model = arg;
    } else if (i == 3) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse r parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }

      if (!Stod(argv[i], r)) {
        Rcout << "\nERROR: Unable to parse r parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (i == 4) {
      *id_col_name = arg;
    } else if (i == 5) {
      *family_col_name = arg;
    } else if (i == 6) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse max_itr parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";





        return false;
      }
      if (!Stoi(argv[i], max_itr)) {
        cout << "ERROR Reading Command: Unable to parse max_itr parameter '"


        << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (i == 7) {
      *delimiter = StripQuotes(argv[i]);
    } else if (i == 8) {
      *comment_char = arg;
    } else if (i == 9) {
      *infinity_char = arg;
    } else if (i == 10) {
      *na_strings = arg;
    } else if (i == 11) {
      *time_params = argv[i];
    } else if (i == 12) {
      *collapse = argv[i];
    } else if (i == 13) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse max_itr parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
      if (!Stod(argv[i], precision)) {
        cout << "ERROR Reading Command: Unable to parse "
             << "convergence_threshold parameter '"
             << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else {
      Rcout << "\nERROR: Unexpected argument: " << argv[i] << endl;
      return false;
    }
  }

  return true;
}

bool SanityCheckArgs(
    const std::string& model, const std::string& family_col,
    const std::string& input_file, const std::string& output_file,
    const double& r) {
  if (family_col.empty()) {
    Rcout << "ERROR: You must specify which is the clustering column (via --family_col "
          << "command-line parameter)." << endl;
    PrintClusteredUsage();
    return false;
  }
  if (model.empty()) {
    Rcout << "ERROR: You must specify a model (via --model "
          << "command-line parameter)." << endl;
    PrintClusteredUsage();
    return false;
  }
  if (input_file.empty()) {
    Rcout << "ERROR: You must specify an input data file (via --in "
          << "command-line parameter)." << endl;
    PrintClusteredUsage();
    return false;
  }
  if (output_file.empty()) {
    Rcout << "ERROR: You must specify an output data file (via --out "
          << "command-line parameter)." << endl;
    PrintClusteredUsage();
    return false;
  }
  if (r < 0.0) {
    Rcout << "ERROR: r (" << r << ") must be non-negative." << endl;
    return false;
  }
  return true;
}

//[[Rcpp::export]]
std::string ClusteredNPMLE(const std::vector<std::string>& r_input) {
  std::string input_file = "";
  std::string output_file = "";
  std::string id_col_name = "";
  std::string family_col_name = "";
  std::string model = "";
  std::string collapse = "";
  std::string norm_params = "";
  std::string time_params = "";
  std::string delimiter = " ";
  std::string comment_char = "";
  std::string infinity_char = "inf";
  std::string na_strings = "NA";

  double r = 0.0;
  double convergence_threshold = 0.0001;
  int h_n_constant = 5;
  int max_itr = 5000;
  bool standardize = true;
  bool standardize_all = false;
  bool no_use_pos_def_variance = false;
  bool force_one_right_censored = true;
  if (!ParseArgs(r_input, &standardize, &standardize_all,
                 &input_file, &output_file, &id_col_name,
                 &family_col_name, &model, &delimiter,
                 &comment_char, &infinity_char, &collapse,
                 &norm_params, &time_params, &na_strings, &r,
                 &convergence_threshold, &h_n_constant, &max_itr)) {
                 PrintClusteredUsage();
    return "ERROR: Unable to run clustreg on parameters provided.\n" + PrintClusteredUsage() + "\n";
  }

  // Sanity-Check provided command-line args are valid.
  if (!SanityCheckArgs(model, family_col_name, input_file, output_file, r)) {
    return "\n" + PrintClusteredUsage();
  }

  // Initialize data structure.
  ModelAndDataParams params;
  params.model_type_ = ModelType::MODEL_TYPE_INTERVAL_CENSORED;
  params.model_str_ = model;
  params.id_str_ = id_col_name;
  params.family_str_ = family_col_name;
  params.collapse_params_str_ = collapse;
  params.time_params_str_ = time_params;
  params.var_norm_params_str_ = norm_params;
  params.standardize_vars_ =
    standardize_all ? VariableNormalization::VAR_NORM_STD_W_N_MINUS_ONE :
    standardize ? VariableNormalization::VAR_NORM_STD_W_N_MINUS_ONE_NON_BINARY :
    VariableNormalization::VAR_NORM_NONE;
  params.max_itr_ = max_itr;
  params.file_.name_ = input_file;
  params.outfile_.name_ = output_file;
  if (!comment_char.empty()) {
    params.file_.comment_char_ = comment_char;
    params.outfile_.comment_char_ = comment_char;
  }
  if (!infinity_char.empty()) {
    params.file_.infinity_char_ = infinity_char;
    params.outfile_.infinity_char_ = infinity_char;
  }
  if (!delimiter.empty()) {
    params.file_.delimiter_ = delimiter;
    params.outfile_.delimiter_ = delimiter;
  }
  if (!na_strings.empty()) {
    std::vector<string> na_strs;
    Split(StripQuotes(na_strings), ",", &na_strs);
    for (const string& na_str : na_strs) {
      params.file_.na_strings_.insert(na_str);
      params.outfile_.na_strings_.insert(na_str);
    }
  }

  // Translate string versions of model parameters (i.e. Category 1 fields of
  // ModelAndDataParams) to the corresponding structures (Category 2 fields).
  if (!ParseModelAndDataParams(&params)) {
    return "ERROR in Parsing Model:\n" + params.error_msg_ + "\n";
  }

  // Convert data into format accepted by underlying algorithm.
  TimeDepIntervalCensoredData data;
  if (!params.id_str_.empty() &&
      !ReadTimeDepIntervalCensoredData::ReadFile(params, &data)) {
      return "ERROR in reading time-dependent data file:\n" + data.error_msg_ + "\n";
  } else if (params.id_str_.empty() &&
    !ReadTimeIndepIntervalCensoredData::ReadFile(params, &data)) {
    return "ERROR in reading time-independent data file:\n" + data.error_msg_ + "\n";
  }

  // Initialize global parameters for underlying algorithm.
  InputValues input;
  ClusteredMpleForIntervalCensoredData::SetLoggingOn(false);
  ClusteredMpleForIntervalCensoredData::SetForceOneRightCensored(force_one_right_censored);
  ClusteredMpleForIntervalCensoredData::SetNoUsePositiveDefiniteVariance(
    false);
  if (!ClusteredMpleForIntervalCensoredData::InitializeInput(r, data, &input)) {
    return "ERROR in parsing data file.\n";
  }

  // =============================== MPLE Start ================================
  const int max_times_em = 2;
  const int kAllowSecondPassTimeThreshold = 60 * 60 * 6;  // 6 hours.
  double final_likelihood = 0.0;
  DependentCovariateEstimates estimates;
  MatrixXd variance;
  double covariance;
  MpleReturnValue ret_value;
  const int orig_h_n_constant = h_n_constant;
  for (int num_times_em = 0; num_times_em < max_times_em; ++num_times_em) {
    time_t mple_start_time = time(nullptr);
    localtime(&mple_start_time);

    DependentCovariateEstimates standardized_estimates;
    h_n_constant = orig_h_n_constant;
    int num_iterations = 0;
    ret_value =
      ClusteredMpleForIntervalCensoredData::PerformEmAlgorithmForParameterEstimation(
        convergence_threshold, h_n_constant, params.max_itr_, input,
        &num_iterations, &final_likelihood, &covariance,
        &standardized_estimates, nullptr);
        if (ret_value != MpleReturnValue::SUCCESS &&
        ret_value != MpleReturnValue::FAILED_MAX_ITR) {
          return "ERROR in Performing E-M Algorithm for Parameter Estimation.\n";
        }

        // Unstandardize beta and variance values.
        std::string error_msg = "";
        if (!ReadTimeDepIntervalCensoredData::UnstandardizeBetaAndLambda(
            params.standardize_vars_,
            standardized_estimates.beta_, standardized_estimates.lambda_,
            data.linear_terms_mean_and_std_dev_[0],
                                               &estimates.beta_, &estimates.lambda_, &error_msg)) {
          return error_msg + "\n";
        }

        // Print beta, lambda estimates to file (in case Variance computation fails).
        if (!PrintOutput(
            data.subject_info_.size(), data.family_index_to_id_.size(),
            params.outfile_.name_, params.model_lhs_.dep_vars_names_,
            data.legend_[0], final_likelihood, covariance,
            input.distinct_times_, estimates, nullptr)) {
          return "ERROR printing output.\n";
        }

        // Handle unsucessful run.
        if (ret_value != MpleReturnValue::SUCCESS) {
          return "ERROR in Performing E-M Algorithm for Parameter Estimation.\n";
        }

        // Now Compute Variance.
        const int max_times_neg_var = 3;
        for (int num_times_neg_var = 0; num_times_neg_var < max_times_neg_var;
        ++num_times_neg_var) {
          MatrixXd standardized_variance;
          if (data.family_index_to_id_.size() == 1) {
            double integral_constant_factor;
            Expression transformation_G, transformation_G_prime;
            if (!MpleForIntervalCensoredData::InitializeInput(
                r, &integral_constant_factor,
                &transformation_G, &transformation_G_prime)) {
              return "ERROR parsing input data file.\n";
            }
            ret_value = MpleForIntervalCensoredData::ComputeVariance(
              transformation_G, transformation_G_prime,
              r, integral_constant_factor, convergence_threshold,
              h_n_constant, params.max_itr_, input.points_and_weights_,
              input.distinct_times_, input.family_values_[0].lower_time_bounds_,
              input.family_values_[0].upper_time_bounds_,
              input.family_values_[0].time_indep_vars_,
              input.family_values_[0].x_, input.family_values_[0].r_star_,
              standardized_estimates.beta_, standardized_estimates.lambda_,
              &standardized_variance);
          } else {
            int n = 0;
            for (const FamilyInputValues& family_info : input.family_values_) {
              n += family_info.lower_time_bounds_.size();
            }
            ret_value =
              ClusteredMpleForIntervalCensoredData::ComputeVariance(
                n, standardized_estimates.beta_.size(),
                h_n_constant, params.max_itr_,
                convergence_threshold, sqrt(covariance),
                input, standardized_estimates, &standardized_variance);
          }

          if (ret_value == MpleReturnValue::SUCCESS) {
            // Note that Covariance matrix is not (p, p), so we need to generate
            // the row/column statistics (mean, std dev) in order to unstandardize it:
            // In Particular, it is (p + 1, p + 1), where the extra coordinate
            // for "covariance" should get mean 0 and std_dev 1.
            std::vector<tuple<bool, double, double>> variance_matrix_means_and_std_dev;
            if (!ExtendLinearTermMeansAndStdDevToCovarianceMatrix(
                data.family_index_to_id_.size(), data.linear_terms_mean_and_std_dev_[0],
                                                                                    &variance_matrix_means_and_std_dev)) {
              return "ERROR in computing variance.\n";
            }

            // Unstandardize Covariance Matrix.
            if (!UnstandardizeMatrix(
                params.standardize_vars_,
                standardized_variance, variance_matrix_means_and_std_dev,
                &variance, &error_msg)) {
              return error_msg + "\n";
            }
            break;
          }

          if (ret_value != MpleReturnValue::FAILED_NEGATIVE_VARIANCE) break;

          // Negative variance. Try to correct by increasing h_n constant.
          if (h_n_constant < 10) h_n_constant = 10;
          else break;
        }

        if (ret_value == MpleReturnValue::SUCCESS) break;

        // To reach here, only possibilities are ret_value equals
        // FAILED_VARIANCE or FAILED_NEG_VARIANCE. Abort in the former case,
        // while attempt to re-run to fix the problem in the latter case.
        if (ret_value == MpleReturnValue::FAILED_VARIANCE) {
          return "ERROR in Computing Variance. "
                 "Even though Variance computation failed, estimates for beta "
                 "and lambda in '" + params.outfile_.name_ + "' are valid.\n";
        }

        // To reach here, Negative Covariance was encounterd (max_times_neg_var
        // times, or with all spacing (h_n) options exhausted). If time permits,
        // rerun E-M algorithm (with stricter convergence threshold) to get new
        // beta, lambda estimates, and try again to compute Covariance Matrix
        // using those.
        time_t mple_end_time = time(nullptr);
        localtime(&mple_end_time);
        time_t mple_elapsed_time = mple_end_time - mple_start_time;  // In seconds.
        if (mple_elapsed_time > kAllowSecondPassTimeThreshold) break;
        convergence_threshold /= 10.0;
        params.max_itr_ *= 2;
  }
  // ================================ MPLE END =================================

  if (ret_value == MpleReturnValue::FAILED_NEGATIVE_VARIANCE) {
    return "ERROR: Information Matrix is not positive definite. "
           "Try rerunning clustreg with decreased convergence_threshold "
           "and increased max_itr.\n";
  } else if (ret_value != MpleReturnValue::SUCCESS) {
    // The only non-success MpleReturnValue that can reach here is FAILED_VAR or
    // FAILED_NEG_VARIANCE (all the others have already done a "return -1" call).
    return "ERROR in Computing Variance. "
           "Even though Variance computation failed, estimates for beta "
           "and lambda in '" + params.outfile_.name_ + "' are valid.\n";
  }

  // (Re)Print results to file, now that we have covariance.
  if (!PrintOutput(
      data.subject_info_.size(), data.family_index_to_id_.size(), params.outfile_.name_,
      params.model_lhs_.dep_vars_names_, data.legend_[0], final_likelihood,
      covariance, input.distinct_times_, estimates, &variance)) {
    return "ERROR printing output.\n";
  }

  time_t current_time = time(nullptr);
  return "\n" + string(asctime(localtime(&current_time))) +
    "Done running clustreg.\nTotal Elapsed Time: ";
}
