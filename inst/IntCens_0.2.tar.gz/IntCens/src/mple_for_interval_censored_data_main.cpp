#include <Rcpp.h>
using namespace Rcpp;

// Date: Nov 2015
// Author: paulbunn@email.unc.edu (Paul Bunn)
// Usage:
//   Valid --model formats:
//     1) (Time-Dependent):   (TIME, STATUS) = MODEL_RHS
//     2) (Time-Independent): ([STATUS_VAR : ]LEFT-END, RIGHT-END) = MODEL_RHS
//   Where 'TIME' and 'STATUS' refer to the names of these columns (in the
//   time-dependent case), and 'LEFT-END' and 'RIGHT-END' refer to the names
//   of the interval endpoint columns (in the time-independent case); and
//   MODEL_RHS is a mathematical expression involving the covariates. The
//   "STATUS_VAR =" part is optional, and gives the user the ability to
//   name the dependent variable (only used to describe it in the output file).
// Note that the id_col argument should be provided iff the data has the
// time-dependent format (and in particular, the --model argument has
// format (1) from above).
// See comments in command_line_utils.h for accepted formats of the args:
//   - extrapolation:   See ParseTimeDependentParams()
//   - standardization: See ParseVariableNormalizationParams()
//   - collapse:        See ParseCollapseParams()
#include "command_line_utils.h"
#include "read_input.h"
#include "read_time_dep_interval_censored_data.h"
#include "read_time_indep_interval_censored_data.h"
#include "mple_for_interval_censored_data.h"
#include "regression_utils.h"
#include "statistics_utils.h"

#include <cstdlib>
#include <Eigen/Dense>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>

using Eigen::MatrixXd;
using Eigen::VectorXd;
using namespace std;

string PrintUsage() {
  return "\nProper Usage:\n"
  "unireg( "
  "input = \"/path/to/input.txt\" "
  "output = \"/path/to/output.txt\" "
  "r = VALUE "
  "model = \"(time, status)=X_1+X_2+...\" "
  "[id_col = ID_COLUMN_NAME] "
  "[max_itr = VALUE]"
  "[sep = INPUT_FILE_DELIMITER] "
  "[comment_char = COMMENT_CHAR] "
  "[inf_char = INFINITY_CHAR] "
  "[missing_value = MISSING_VALUE_STRING] "
  "[extrapolation = EXTRAPOLOATION_PARAMS] "
  "[collapse = \"VAR_1 = {FROM_VAL_1, FROM_VAL_2, ...} -> TO_VAL; "
  "...; VAR_N = {FROM_VAL_1, FROM_VAL_2, ...} -> TO_VAL\"] "
  "[convergence_threshold VALUE] "
  "\n\n";
}

bool PrintOutput(
    const std::string& output_file,
    const int num_subjects,
    const std::vector<std::string>& legend,
    const std::set<double>& distinct_times,
    const double& final_likelihood,
    const VectorXd& beta, const VectorXd& lambda,
    const MatrixXd* variance) {
  const int p = legend.size();
  if (p == 0 || beta.size() != p ||
      (variance != nullptr && (variance->rows() != p || variance->cols() != p))) {
    Rcout << "ERROR: Mismatching dimensions. Model:\n\t"
         << Join(legend, " + ") << "\nBeta size: " << beta.size()
         << ", Covariance Matrix size: (" << variance->rows() << ", "
         << variance->cols() << ")." << endl;
    return false;
  }

  ofstream outfile;
  outfile.open(output_file.c_str());

  // Print Metadata (command, num subjects, num distinct time points).
  outfile << "Num Subjects: " << num_subjects << endl
          << "Num distinct time points: " << distinct_times.size() << endl
          << "Log-Likelihood at the final estimates: " << final_likelihood << endl
          << "###############################################################"
          << endl << "Estimation of the Regression Parameters:" << endl << endl;

  // Beta Estimates.
  if (variance != nullptr) {
    VectorXd z_stats, p_values;
    if (!GenerateSummaryStatisticsFromCovarianceMatrix(
        beta, *variance, &z_stats, &p_values)) {
      Rcout << "ERROR: Failed to generate summary statistics for estimates:\n"
           << beta << "\nand Covariance Matrix:\n" << *variance << endl
           << "ERROR: NEGATIVE VARIANCE DETECTED" << endl;
      return false;
    }

    outfile << setprecision(17);
    outfile << "Covariate\tEstimate\tStd_Error\tZ-Stat\tP-value" << endl;
    for (int i = 0; i < p; ++i) {
      outfile << legend[i] << "\t" << beta(i) << "\t" << sqrt((*variance)(i, i))
              << "\t" << z_stats(i) << "\t" << p_values(i) << endl;
    }
  } else {
    outfile << setprecision(17);
    outfile << "Covariate\tEstimate" << endl;
    for (int i = 0; i < p; ++i) {
      outfile << legend[i] << "\t" << beta(i) << endl;
    }
  }
  outfile << endl;

  // Variance.
  if (variance != nullptr) {
    outfile << setprecision(17);
    if (p > 1) {
      outfile << "Covariance Matrix for the Estimates:" << endl << "\t";
      for (int i = 0; i < p; ++i) {
        outfile << "\t" << legend[i];
      }
    } else {
      outfile << "Variance";
    }
    outfile << endl;
    for (int i = 0; i < p; ++i) {
      outfile << "\t" << legend[i] << ":";
      for (int j = 0; j < p; ++j) {
        outfile << "\t" << (*variance)(i, j);
      }
      outfile << endl;
    }
  }

  // Lambda.
  outfile << endl << "Estimation of the Cummulative Hazard Function:" << endl
          << "Time\tEstimate" << endl;
  if (distinct_times.size() != lambda.size()) {
    Rcout << "ERROR: Mismatching number of distinct times ("
         << distinct_times.size() << ") and size of lambda ("
         << lambda.size() << ")." << endl;
    return false;
  }
  int k = -1;
  double cumm_lambda = 0.0;
  for (const double& time : distinct_times) {
    k++;
    cumm_lambda += lambda(k);
    outfile << setprecision(6) << time << "\t"
            << setprecision(10) << cumm_lambda << endl;
  }

  outfile.close();

  return true;
}

bool ParseArgs(
    const std::vector<std::string>& argv, bool* standardize, bool* standardize_all,
    std::string* input_file, std::string* output_file, std::string* id_col_name,
    std::string* model, std::string* delimiter, std::string* comment_char,
    std::string* infinity_char, std::string* collapse, std::string* norm_params,
    std::string* time_params, std::string* na_strings,
    double* r, double* precision, int* spacing, int* max_itr) {
  // Start loop at '1' (argument 0 is the executable itself).
  // Start loop at '1' (argument 0 is the executable itself).
  const unsigned int argc = argv.size();
  if (argc != 13) {
    Rcout << "\nERROR: unireg expects 13 arguments, found "
          << argc << endl;
    return false;
  }
  for (unsigned int i = 0; i < argc; ++i) {
    const string& arg = StripAllEnclosingPunctuationAndWhitespace(argv[i]);
    if (i == 0) {
      *input_file = arg;
    } else if (i == 1) {
      *output_file = arg;
    } else if (i == 2) {
      *model = arg;
    } else if (i == 3) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse r parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }

      if (!Stod(argv[i], r)) {
        Rcout << "\nERROR: Unable to parse r parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (i == 4) {
      *id_col_name = arg;
    } else if (i == 5) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse max_itr parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";





        return false;
      }
      if (!Stoi(argv[i], max_itr)) {
        cout << "ERROR Reading Command: Unable to parse max_itr parameter '"


        << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else if (i == 6) {
      *delimiter = StripQuotes(argv[i]);
    } else if (i == 7) {
      *comment_char = arg;
    } else if (i == 8) {
      *infinity_char = arg;
    } else if (i == 9) {
      *na_strings = arg;
    } else if (i == 10) {
      *time_params = argv[i];
    } else if (i == 11) {
      *collapse = argv[i];
    } else if (i == 12) {
      if (arg.empty()) {
        Rcout << "\nERROR: Unable to parse max_itr parameter '"
              << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
      if (!Stod(argv[i], precision)) {
        cout << "ERROR Reading Command: Unable to parse "
             << "convergence_threshold parameter '"
             << argv[i] << "' as a numeric value.\nAborting.\n";
        return false;
      }
    } else {
      Rcout << "\nERROR: Unexpected argument: " << argv[i] << endl;
      return false;
    }
  }

  return true;
}

bool SanityCheckArgs(
    const std::string& model, const std::string& input_file, const std::string& output_file,
    const double& r) {
  if (model.empty()) {
    Rcout << "ERROR: You must specify a model (via --model "
          << "command-line parameter)." << endl;
    PrintUsage();
    return false;
  }
  if (input_file.empty()) {
    Rcout << "ERROR: You must specify an input data file (via --in "
          << "command-line parameter)." << endl;
    PrintUsage();
    return false;
  }
  if (output_file.empty()) {
    Rcout << "ERROR: You must specify an output data file (via --out "
          << "command-line parameter)." << endl;
    PrintUsage();
    return false;
  }
  if (r < 0.0) {
    Rcout << "ERROR: r (" << r << ") must be non-negative." << endl;
    return false;
  }
  return true;
}

//[[Rcpp::export]]
std::string UnivariateNPMLE(const std::vector<std::string>& input) {
  std::string input_file = "";
  std::string output_file = "";
  std::string id_col_name = "";
  std::string model = "";
  std::string collapse = "";
  std::string norm_params = "";
  std::string time_params = "";
  std::string delimiter = " ";
  std::string comment_char = "";
  std::string infinity_char = "inf";
  std::string na_strings = "NA";

  double r = 0.0;
  double convergence_threshold = 0.0001;
  int h_n_constant = 5;
  int max_itr = 5000;
  bool standardize = true;
  bool standardize_all = false;
  bool no_use_pos_def_variance = false;
  bool force_one_right_censored = true;
  if (!ParseArgs(input, &standardize, &standardize_all,
                 &input_file, &output_file, &id_col_name, &model, &delimiter,
                 &comment_char, &infinity_char, &collapse,
                 &norm_params, &time_params, &na_strings, &r,
                 &convergence_threshold, &h_n_constant, &max_itr)) {
                 PrintUsage();
    return "ERROR: Unable to run unireg on parameters provided.\n" + PrintUsage() + "\n";
  }

  // Sanity-Check provided command-line args are valid.
  if (!SanityCheckArgs(model, input_file, output_file, r)) {
    return "\n" + PrintUsage();
  }

  // Initialize data structure.
  ModelAndDataParams params;
  params.model_type_ = ModelType::MODEL_TYPE_INTERVAL_CENSORED;
  params.model_str_ = model;
  params.id_str_ = id_col_name;
  params.collapse_params_str_ = collapse;
  params.time_params_str_ = time_params;
  params.var_norm_params_str_ = norm_params;
  params.standardize_vars_ =
      standardize_all ? VariableNormalization::VAR_NORM_STD_W_N_MINUS_ONE :
      standardize ? VariableNormalization::VAR_NORM_STD_W_N_MINUS_ONE_NON_BINARY :
      VariableNormalization::VAR_NORM_NONE;
  params.max_itr_ = max_itr;
  params.file_.name_ = input_file;
  params.outfile_.name_ = output_file;
  if (!comment_char.empty()) {
    params.file_.comment_char_ = comment_char;
    params.outfile_.comment_char_ = comment_char;
  }
  if (!infinity_char.empty()) {
    params.file_.infinity_char_ = infinity_char;
    params.outfile_.infinity_char_ = infinity_char;
  }
  if (!delimiter.empty()) {
    params.file_.delimiter_ = delimiter;
    params.outfile_.delimiter_ = delimiter;
  }
  if (!na_strings.empty()) {
    std::vector<string> na_strs;
    Split(StripQuotes(na_strings), ",", &na_strs);
    for (const string& na_str : na_strs) {
      params.file_.na_strings_.insert(na_str);
      params.outfile_.na_strings_.insert(na_str);
    }
  }

  // Translate string versions of model parameters (i.e. Category 1 fields of
  // ModelAndDataParams) to the corresponding structures (Category 2 fields).
  if (!ParseModelAndDataParams(&params)) {
    return "ERROR in Parsing Model:\n" + params.error_msg_ + "\n";
  }

  // Convert data into format accepted by underlying algorithm.
  TimeDepIntervalCensoredData data;
  if (!params.id_str_.empty() &&
      !ReadTimeDepIntervalCensoredData::ReadFile(params, &data)) {
    return "ERROR in reading time-dependent data file:\n" + data.error_msg_ + "\n";
  } else if (params.id_str_.empty() &&
             !ReadTimeIndepIntervalCensoredData::ReadFile(params, &data)) {
    return "ERROR in reading time-independent data file:\n" + data.error_msg_ + "\n";
  }

  // Initialize global parameters for underlying algorithm.
  max_itr = params.max_itr_;
  MpleForIntervalCensoredData::SetLoggingOn(false);
  MpleForIntervalCensoredData::SetNoUsePositiveDefiniteVariance(
    no_use_pos_def_variance);
  MpleForIntervalCensoredData mple(
      false, force_one_right_censored, r, convergence_threshold,
      h_n_constant, max_itr, 40);
  // Convert data to the format accepted by MpleForIntervalCensoredData.
  mple.InitializeData(data);
  mple.InitializeTimers();

  // =============================== MPLE START ================================
  // Get Estimates for beta, lambda (Covariance will be done separately below).
  const int max_times_em = 2;
  const int kAllowSecondPassTimeThreshold = 60 * 60 * 6;  // 6 hours.
  double final_likelihood = 0.0;
  VectorXd beta, lambda;
  // Explicitly set beta and lambda to be empty, which indicates to E-M
  // algorithm that the default start values should be used (otherwise,
  // E-M algorithm will use beta, lambda values that are passed-in to
  // start the algorithm).
  beta.resize(0);
  lambda.resize(0);
  MatrixXd variance;
  MpleReturnValue ret_value;
  for (int num_times_em = 0; num_times_em < max_times_em; ++num_times_em) {
    time_t mple_start_time = time(nullptr);
    localtime(&mple_start_time);

    // Update max_itr and convergence threshold, if the first E-M algorithm failed.
    if (num_times_em > 0) {
      mple.SetConvergenceThreshold(convergence_threshold);
      mple.SetMaxItr(max_itr);
    }

    int num_iterations = 0;
    VectorXd standardized_beta, standardized_lambda;
    ret_value = mple.PerformEmAlgorithmForParameterEstimation(
        &num_iterations, &final_likelihood,
        &standardized_beta, &standardized_lambda, nullptr);
    if (ret_value != MpleReturnValue::SUCCESS &&
    ret_value != MpleReturnValue::FAILED_MAX_ITR) {
      return "ERROR in Performing E-M Algorithm for Parameter Estimation.\n";
    }

    // Unstandardize beta and lambda for printing.
    std::string error_msg = "";
    if (!ReadTimeDepIntervalCensoredData::UnstandardizeBetaAndLambda(
        params.standardize_vars_, standardized_beta, standardized_lambda,
        data.linear_terms_mean_and_std_dev_[0], &beta, &lambda, &error_msg)) {
      return error_msg + "\n";
    }

    // Print beta and lambda to file.
    if (!PrintOutput(params.outfile_.name_, data.subject_info_.size(),
                     data.legend_[0], mple.GetDistinctTimes(),
                     final_likelihood, beta, lambda, nullptr)) {
      return "ERROR printing output.\n";
    }

    // Handle unsucessful run.
    if (ret_value != MpleReturnValue::SUCCESS) {
      return "ERROR in Performing E-M Algorithm for Parameter Estimation due "
             "to exceeding the maximum allowed iterations (" + Itoa(max_itr) + ").\n"
             "Values of Beta and Lambda as of the last iteration are "
             "available in: " + params.outfile_.name_ + "\n";
    }

    // Now Compute Covariance Matrix.
    const int max_times_neg_var = 3;
    for (int num_times_neg_var = 0; num_times_neg_var < max_times_neg_var;
    ++num_times_neg_var) {
      MatrixXd standardized_variance;
      ret_value = mple.ComputeVariance(
        standardized_beta, standardized_lambda, &standardized_variance);

      if (ret_value == MpleReturnValue::SUCCESS) {
        // Unstandardize Covariance Matrix.
        if (!UnstandardizeMatrix(
            params.standardize_vars_,
            standardized_variance, data.linear_terms_mean_and_std_dev_[0],
                                                                      &variance, &error_msg)) {
          return error_msg + "\n";
        }
        break;
      }

      if (ret_value != MpleReturnValue::FAILED_NEGATIVE_VARIANCE) break;

      // Negative variance. Try to correct by increasing h_n constant.
      const int current_h_n = mple.GetHn();
      if (current_h_n < 10) mple.SetHn(10);
      else break;
    }

    if (ret_value == MpleReturnValue::SUCCESS) break;

    // To reach here, only possibilities are ret_value equals
    // FAILED_VARIANCE or FAILED_NEG_VARIANCE. Abort in the former case,
    // while attempt to re-run to fix the problem in the latter case.
    if (ret_value == MpleReturnValue::FAILED_VARIANCE) {
      return "ERROR in Computing Variance.  "
             "Even though Variance computation failed, estimates for beta "
             "and lambda in '" + params.outfile_.name_ + "' are valid.\n";
    }

    // To reach here, Negative Covariance was encounterd (max_times_neg_var
    // times, or with all spacing (h_n) options exhausted). If time permits,
    // rerun E-M algorithm (with stricter convergence threshold) to get new
    // beta, lambda estimates, and try again to compute Covariance Matrix
    // using those.
    time_t mple_end_time = time(nullptr);
    localtime(&mple_end_time);
    time_t mple_elapsed_time = mple_end_time - mple_start_time;  // In seconds.
    if (mple_elapsed_time > kAllowSecondPassTimeThreshold ||
        max_itr != 5000 || convergence_threshold != 0.0001) break;
    convergence_threshold /= 10.0;
    max_itr *= 2;
  }
  // ================================ MPLE END =================================
  if (ret_value == MpleReturnValue::FAILED_NEGATIVE_VARIANCE) {
    return "ERROR: Information Matrix is not positive definite. "
           "Try rerunning unireg with decreased convergence_threshold "
           "and increased max_itr.\n";
  } else if (ret_value != MpleReturnValue::SUCCESS) {
    // The only non-success MpleReturnValue that can reach here is FAILED_VAR or
    // FAILED_NEG_VARIANCE (all the others have already done a "return -1" call).
    return "ERROR in Computing Variance. "
           "Even though Variance computation failed, estimates for beta "
           "and lambda in '" + params.outfile_.name_ + "' are valid.\n";
  }

  // (Re)Print results to file, now that we have covariance.
  if (!PrintOutput(params.outfile_.name_, data.subject_info_.size(),
                   data.legend_[0], mple.GetDistinctTimes(),
                   final_likelihood, beta, lambda, &variance)) {
    return "ERROR printing output.\n";
  }
  time_t current_time = time(nullptr);
  return "\n" + string(asctime(localtime(&current_time))) +
    "Done running unireg.\nTotal Elapsed Time: ";
}
