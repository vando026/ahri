#include <Rcpp.h>
using namespace Rcpp;

// Date: Sep 2015
// Author: paulbunn@email.unc.edu (Paul Bunn)

#include "constants.h"

const double Z_SCORE_FOR_TWO_TAILED_FIVE_PERCENT = 1.9599639845;
const double PHB_PI = 3.14159265358979323846264338327950;
const double DELTA = 0.01;  // 10^-2
const double EPSILON = 0.000001;  // 10^-6

const char PHB_NA_STRING[] = "PHB_NA_PHB";
const char RHS_STRING[] = "PHB_RHS_PHB";
