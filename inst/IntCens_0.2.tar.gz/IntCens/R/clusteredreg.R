clustreg <- function(input="", output="", r=0.0, model="", subject_id="",
                   cluster_id="", max_itr=5000,
                   sep=" ", comment_char="", inf_char="inf", missing_value="NA",
                   extrapolation="", collapse="",
                   convergence_threshold=0.005) {
  start_time = proc.time()
  foo = c(input, output, model, as.character(r), subject_id, cluster_id, as.character(max_itr),
          sep, comment_char, inf_char, missing_value,
          extrapolation, collapse, convergence_threshold)
  cat(.Call('IntCens_ClusteredNPMLE', PACKAGE = 'IntCens', foo))
  bar = proc.time() - start_time
  print(cat(as.character(bar[3]), " seconds\n",
            "Check output in: ", output, "\n", sep = ""))
}
