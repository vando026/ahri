multireg <- function(input="", output="", r=0.0, models="", subject_id="", event_type="",
                     max_itr=5000,
                   sep=" ", comment_char="", inf_char="inf", missing_value="NA",
                   extrapolation="", collapse="",
                   convergence_threshold=0.005, event_order="") {
  start_time = proc.time()
  foo = c(input, output, as.character(r), models, subject_id, event_type,
          as.character(max_itr),
          sep, comment_char, inf_char, missing_value,
          extrapolation, collapse, convergence_threshold, event_order)
  cat(.Call('IntCens_MultivariateNPMLE', PACKAGE = 'IntCens', foo))
  bar = proc.time() - start_time
  print(cat(as.character(bar[3]), " seconds\n",
            "Check output in: ", output, "\n", sep = ""))
}
